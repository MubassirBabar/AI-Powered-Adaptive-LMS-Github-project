package database

type User struct {
	Email        string
	Username     string
	PasswordHash string
}
